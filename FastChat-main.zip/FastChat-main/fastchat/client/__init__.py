from fastchat.client.api import ChatCompletion, set_baseurl

__all__ = ["ChatCompletion", "set_baseurl"]
