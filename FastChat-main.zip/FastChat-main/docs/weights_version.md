See [vicuna_weights_version.md](vicuna_weights_version.md) for vicuna weights version.
